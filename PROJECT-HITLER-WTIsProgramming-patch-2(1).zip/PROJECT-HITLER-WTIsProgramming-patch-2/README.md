# PROJECT-HITLER

Bezoek de website?
-
https://project-hitler.herokuapp.com/

Download de gehele repo?
-
-Selecteer eerst de juiste branch, 'Master' wordt gebruikt op de website.

-Klik op de groene knop genaamd 'clone or download' en download het als ZIP bestand.

Run de app op je lokale (windows)computer?
-
-pak het ZIP bestand uit

-installeer de volgende modules in het uitgepakte mapje: NodeJS, Express, Socket.io

-start de NodeJS server via CMD met 'npm start'.

Wil je iets toevoegen aan de repo?
-
-Push naar de branch genaamd testing.

-Niet pushen naar de branch Master zonder overleg!
